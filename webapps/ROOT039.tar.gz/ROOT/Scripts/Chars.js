//Caracteres especiales en formato UNICODE

var _oQuestion  = '\u00BF';    // Abre interrogacion
var _cQuestion  = '\u003F';    // Cierra interrogacion
var _aAccute    = '\u00E1';    // a acentuada
var _eAccute    = '\u00E0';    // e acentuada
var _iAccute    = '\u00ED';    // i acentuada
var _oAccute    = '\u00F3';    // o acentuada
var _uAccute    = '\u00FA';    // u acentuada
var _nTilde     = '\u00F1';    // n tilde

