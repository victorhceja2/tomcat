
CREATE TABLE op_hh_ageb(
	ageb_id varchar(5) NOT NULL PRIMARY KEY,
	house_hold INT,
	target SMALLINT,
	active boolean);
