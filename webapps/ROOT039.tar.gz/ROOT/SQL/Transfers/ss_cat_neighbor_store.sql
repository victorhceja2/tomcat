
-- Structure

CREATE TABLE ss_cat_neighbor_store (
    store_id smallint NOT NULL PRIMARY KEY,
    store_desc character varying(50),
    area_id character varying(10)
);
