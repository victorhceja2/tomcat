CREATE TABLE op_grl_existence(
			inv_id char(6) NOT NULL PRIMARY KEY,
			quantity float);
