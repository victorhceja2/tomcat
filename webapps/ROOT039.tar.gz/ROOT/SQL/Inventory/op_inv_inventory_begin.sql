
CREATE TABLE op_inv_inventory_begin(
			inv_id  CHAR(6) NOT NULL PRIMARY KEY,
			inv_beg FLOAT,
            week_no SMALLINT);
