export CLASSPATH=.:../lib/commons-fileupload-1.0.jar:../lib/radius.jar:../lib/activation.jar:../lib/mail.jar:../lib/postgresql.jar:../lib/ldap.jar:/usr/local/netbeans/tomcat406/common/lib/servlet.jar
javac generals/*.java
javac generals/servlets/*.java


