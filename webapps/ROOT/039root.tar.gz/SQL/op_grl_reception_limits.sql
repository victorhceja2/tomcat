
CREATE TABLE op_grl_reception_limits (
    provider_id character(10),
    provider_product_code character(10),
    limit_quantity numeric(12,2)
);

