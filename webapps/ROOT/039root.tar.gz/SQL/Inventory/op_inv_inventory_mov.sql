
CREATE TABLE op_inv_inventory_mov(
 inv_id  character(6),
 provider_product_code  character(10),
 receptions             numeric,
 input_transfers        numeric,
 output_transfers       numeric);

