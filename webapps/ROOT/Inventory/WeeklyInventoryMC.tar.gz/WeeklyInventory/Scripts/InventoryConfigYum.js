var gfMinEfficiency = 90;  
var gfMaxEfficiency = 100;  //100% de eficiencia
var gfMaxVariance   = 0.0015; //.15% de la venta neta
